package com.herprogramacion.movielife.net;

/**
 * Created by root on 22/04/17.
 */

public class FirebaseReferences {
    public final static String CRUD_REFERENCE = "crud";
    public final static String ESTRENOS_REFERNCE = "estrenos";
    public final static String PELICULAS_REFERENCE = "peliculas_favoritas";
    public final static String CINES_REFERENCE = "cines_favoritos";
}
